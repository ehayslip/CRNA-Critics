# CRNA Critics — server edition

A real backend for CRNA Critics: Node/Express + SQLite, with email-based
verification (name/NBCRNA#/email/phone → admin approves via a one-tap link
in their inbox → CRNA signs in with a passwordless magic link) and the same
rating system as before — Agency & Agent (6 weighted categories + pay range,
scored separately), Hospital (8 weighted categories including Supervision /
Practice Autonomy), delete-your-own-review.

## What's different from the artifact version

- Real database (SQLite file, `data.db`) instead of browser storage.
- Real email: submitting a verification request emails you (`ADMIN_EMAIL`)
  with **Approve** / **Reject** buttons that work with one tap, no login
  needed. Approving auto-emails the CRNA a sign-in link.
- Sessions are signed, `httpOnly` cookies — not a client-side passcode
  anyone can read in page source.
- CRNAs sign in with a magic link emailed to their address, not a typed
  name.

## 1. Install

Requires Node 18+.

```bash
npm install
```

## 2. Configure

```bash
cp .env.example .env
```

Then edit `.env`:

- `APP_SECRET` — generate with:
  `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
- `ADMIN_PASSCODE` — whatever you want to log into `/api/admin/login` with.
  This still isn't the *only* way into the admin dashboard's approve/reject
  actions — the emailed one-tap links work independently of it, signed with
  `APP_SECRET`.
- `ADMIN_EMAIL` — where "new applicant" emails go.
- `RESEND_API_KEY` — sign up free at [resend.com](https://resend.com), create
  an API key. Leave blank to test locally without sending real email —
  outgoing emails get logged to the console instead (link included), so you
  can still click through everything during development.
- `FROM_EMAIL` — their shared `onboarding@resend.dev` works for testing;
  verify your own domain in Resend for production.
- `BASE_URL` — must match wherever this is actually reachable, or the links
  inside emails will point to the wrong place. `http://localhost:3000` for
  local dev; your real domain once deployed.

## 3. Run

```bash
npm start
```

Visit `http://localhost:3000`.

## 4. Deploy

This is a normal Node app — no special build step. Any host that runs
`npm install && npm start` and gives you a persistent disk works: Railway,
Render, Fly.io, a plain VPS, etc.

Two things to watch:
- **`better-sqlite3` is a native module.** Most hosts (Railway, Render,
  Fly.io) build it automatically on deploy. If you use something that
  doesn't compile native modules, you'd need to swap in a hosted Postgres
  and change `server/db.js` accordingly — ask me and I'll do that swap.
- **`data.db` needs to live on a persistent volume**, not an ephemeral
  filesystem that resets on every deploy — otherwise you lose all reviews
  and accounts on the next deploy. Check your host's docs for "persistent
  disk" or "volume."

Set the same environment variables from `.env` in your host's dashboard
(don't commit `.env` itself), and update `BASE_URL` to your real domain.

## 5. First admin approval

There's a bit of a bootstrapping step: the very first CRNA (probably you)
still has to submit the "Request verification" form like anyone else, then
approve themselves from the emailed link or the `/api/admin` dashboard.

## Project layout

```
server/
  index.js   — Express app, all routes
  db.js      — SQLite schema
  auth.js    — signed-cookie / email-link tokens
  email.js   — Resend wrapper
public/
  index.html, app.js, styles.css  — the frontend (no build step, vanilla JS)
data.db      — created automatically on first run
```

## Notes on what's simplified

- No password reset flow, no email-change flow — CRNAs always sign in via
  a fresh magic link.
- Admin is a single shared passcode, not individual admin accounts.
- No rate limiting on the request-access or sign-in endpoints yet — worth
  adding before this is public and gets any real traffic (a proper rate
  limiter middleware like `express-rate-limit` is the easy first step).
